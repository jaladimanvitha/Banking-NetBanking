package com.dao;

import com.model.Customer;

public interface CustomerDao {
	public boolean register(Customer customer);
	public int update(Customer customer);
	public int passwordRequest(Customer customer);
	public boolean forgetPassword(String customer_id);
	public void viewBalance();

}

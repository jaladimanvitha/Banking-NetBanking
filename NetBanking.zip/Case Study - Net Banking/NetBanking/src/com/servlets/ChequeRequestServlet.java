package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.controller.RequestImplement;
import com.model.ChequeBook;

/**
 * Servlet implementation class ChequeRequestServlet
 */
public class ChequeRequestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ChequeRequestServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		String account_no=request.getParameter("acc_no");
		Random rnd=new Random();
		long cbno=(long)1+rnd.nextInt(999999);
		HttpSession session=request.getSession();
		String cutomer_id=(String)session.getAttribute("cid");
		String status="Requested";
		ChequeBook cb=new ChequeBook(cutomer_id,account_no,cbno,status);
		RequestImplement ri=new RequestImplement();
        boolean cus=ri.requestchequebook(cb);
        System.out.println(cus);
        if(cus==true)
        {
              pw.println("Request raised");
              RequestDispatcher rd = request.getRequestDispatcher("CustHome.jsp");
                   rd.include(request, response);
        }
              
}

}

package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.controller.PasswordImplement;
import com.model.ChangePassword;

/**
 * Servlet implementation class AdminCustChangePass
 */
public class AdminCustChangePass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminCustChangePass() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		//HttpSession session=request.getSession();
		String cust_id=request.getParameter("cust_id");
		String new_pass=request.getParameter("new_pass");
		//Connection con=MyDBConnection.getConnection();
			ChangePassword c=new ChangePassword(cust_id,new_pass);
			PasswordImplement pi=new PasswordImplement();
			boolean cus=pi.changeACustomerPassword(cust_id, new_pass);
			System.out.println(c);
			if(cus==true){
				pw.print("Customer Password Changed Sucessfull");
				RequestDispatcher rd=request.getRequestDispatcher("AdminPassChange.html");
				rd.include(request, response);
			}
	}

}

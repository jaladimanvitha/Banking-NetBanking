package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.connection.MyDBConnection;
import com.controller.TransactionImplement;
import com.dao.TransactionDao;
import com.model.Transaction;

/**
 * Servlet implementation class TransferServlet
 */
public class TransferServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TransferServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		long account_no=Long.parseLong(request.getParameter("acc_no"));
		float amount=Float.parseFloat(request.getParameter("amount"));
		Random rnd=new Random();
		String trans_id=String.valueOf(1+rnd.nextInt(999999));
		HttpSession session=request.getSession();
		String customer_id=(String)session.getAttribute("cid");
		//System.out.println(customer_id);
		Date dt=new Date();
		java.sql.Date sqldate=new java.sql.Date(dt.getTime());
		Connection con=null;
		long dacc_no=0;
		con=MyDBConnection.getConnection();
		PreparedStatement pr=null;
		try {
			pr=con.prepareStatement("select acc_no from customer where customer_id=?");
			pr.setString(1,customer_id);
			ResultSet rs=pr.executeQuery();
			while(rs.next()){
				dacc_no=rs.getLong(1);
			}
			System.out.println(dacc_no);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(trans_id+"  "+customer_id+"  "+dacc_no+"  "+account_no+"  "+sqldate+"  "+amount);
		Transaction t=new Transaction(trans_id,customer_id,dacc_no,account_no,sqldate,amount);
		TransactionDao td=new TransactionImplement();
		boolean cus=td.transferfund(t);
		System.out.println(cus);
		if(cus==true){
			pw.println("Fund Transfered");
			RequestDispatcher rd=request.getRequestDispatcher("CustHome.jsp");
			rd.include(request, response);
		}
		
	}

}

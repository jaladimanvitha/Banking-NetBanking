package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.controller.PasswordImplement;
import com.model.ChangePassword;

/**
 * Servlet implementation class CustomerChangePass
 */
public class CustomerChangePass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CustomerChangePass() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		HttpSession session=request.getSession();
		String old_pass=request.getParameter("old_pass");
		String new_pass=request.getParameter("new_pass");
		String con_pass=request.getParameter("re_pass");
		//Connection con=MyDBConnection.getConnection();
		String c_id=(String)session.getAttribute("cid");
		String password=(String)session.getAttribute("c_pass");
		if(old_pass.equals(null)||old_pass==""||new_pass.equals(null)||new_pass==""||con_pass.equals(null)||con_pass==""){
			request.setAttribute("msg","All Fields are Manadatory");
			RequestDispatcher rd=request.getRequestDispatcher("passwordrequest.jsp");
			rd.forward(request, response);
		}
		else if(!new_pass.equals(con_pass)){
			request.setAttribute("msg","New Password Do Not Match");
			RequestDispatcher rd=request.getRequestDispatcher("passwordrequest.jsp");
			rd.forward(request, response);
		}
		else if(!password.equals(old_pass)){
			request.setAttribute("msg","Invalid Old Password");
			RequestDispatcher rd=request.getRequestDispatcher("passwordrequest.jsp");
			rd.forward(request, response);
		}
		else{
			ChangePassword c=new ChangePassword(c_id,old_pass,new_pass,con_pass);
			PasswordImplement pi=new PasswordImplement();
			boolean cus=pi.changeCustomerPassword(c);
			System.out.println(c);
			if(cus==true){
				pw.print("Password Changed Sucessfull");
				RequestDispatcher rd=request.getRequestDispatcher("CustHome.jsp");
				rd.include(request, response);
			}
		}
	}

}

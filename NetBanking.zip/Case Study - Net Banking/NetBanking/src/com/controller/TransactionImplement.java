package com.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.connection.MyDBConnection;
import com.dao.TransactionDao;
import com.model.Transaction;

public class TransactionImplement implements TransactionDao{

	public ArrayList<ResultSet> viewAccountDetails(String customer_id) {
		// TODO Auto-generated method stub
		Connection con=null;
		ArrayList<ResultSet> rlist=new ArrayList<ResultSet>();
		ResultSet rs=null;
		con=MyDBConnection.getConnection();
		PreparedStatement pr=null;
		try {
			pr=con.prepareStatement("select * from account where customer_id=?");
			pr.setString(1, customer_id);
			rs=pr.executeQuery();
			while(rs.next()){
				rlist.add(rs);
			}
			return rlist;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				pr.close();
				rs.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		return rlist;
	}

	public boolean transferfund(Transaction transaction) {
		// TODO Auto-generated method stub
		Connection con=null;
		PreparedStatement pr=null;
		PreparedStatement pr1=null;
		PreparedStatement pr2=null;
		PreparedStatement pr3=null;
		PreparedStatement pr4=null;
		try{
		con=MyDBConnection.getConnection();
        con.setAutoCommit(false);
        pr=con.prepareStatement("select balance from account where account_no=?");
        pr1=con.prepareStatement("select balance,a.account_no from account a,beneficiary b where (a.account_no=b.acc_no and status='Active') and a.account_no=?");
        pr2=con.prepareStatement("update account set balance=? where account_no=?");
        pr3=con.prepareStatement("update account set balance=? where account_no=?");
        pr4=con.prepareStatement("insert into transaction values(?,?,?,?,?,?)");
        long m_Debit_Acc_No=transaction.getDebit_AccNo();
        long m_Credit_Acc_No=transaction.getCredit_AccNo();
        
        pr.setLong(1, m_Debit_Acc_No);
        float debit_Bal=0;
        ResultSet rs1=pr.executeQuery();
        while(rs1.next()){
              debit_Bal=rs1.getFloat(1);
        }
        //System.out.println(m_Debit_Acc_No);
        System.out.println(m_Credit_Acc_No);
        System.out.println(debit_Bal);
        pr1.setLong(1, m_Credit_Acc_No);
        float credit_Bal=0;
        ResultSet rs2=pr1.executeQuery();
        while(rs2.next()){
              credit_Bal=rs2.getFloat(1);
              System.out.println(credit_Bal);
        }
        System.out.println(credit_Bal);
        float new_Debit_Bal=(debit_Bal-transaction.getAmount());
        System.out.println(new_Debit_Bal);
        float new_Credit_Bal=(credit_Bal+transaction.getAmount());
        System.out.println(new_Credit_Bal);
        pr2.setFloat(1, new_Debit_Bal);
        pr2.setLong(2, m_Debit_Acc_No);
        int res=pr2.executeUpdate();
        System.out.println("res");
        pr3.setFloat(1, new_Credit_Bal);
        pr3.setLong(2, m_Credit_Acc_No);
        int res1=pr3.executeUpdate();
        System.out.println("res1");
        pr4.setString(1,transaction.getTrans_Id());
        pr4.setString(2,transaction.getCustomer_Id());
        pr4.setLong(3,transaction.getDebit_AccNo());
        pr4.setLong(4,transaction.getCredit_AccNo());
        pr4.setDate(5,transaction.getTrans_Date());
        pr4.setFloat(6,transaction.getAmount());
        int res2=pr4.executeUpdate();
        System.out.println("res2");
        if(res>0 && res1>0 && res2>0){
        	con.commit();
              return true;
        }
 } catch (SQLException e) {
        e.printStackTrace();
        try {
              con.rollback();
        } catch (SQLException e1) {
              e1.printStackTrace();
        }
 }finally{
        try {
        	pr4.close();
        	pr3.close();
        	pr2.close();
        	pr1.close();
        	pr.close();
              con.close();
        } catch (SQLException e) {
              e.printStackTrace();
        }
 }

		return false;
	}

}

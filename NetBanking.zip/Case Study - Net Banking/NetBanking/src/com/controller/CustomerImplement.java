package com.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.connection.MyDBConnection;
import com.dao.CustomerDao;
import com.model.Customer;


public class CustomerImplement implements CustomerDao {
         PreparedStatement pr=null;
         Connection con=MyDBConnection.getConnection();
	public boolean register(Customer customer) {
		// TODO Auto-generated method stub
		try {
			pr=con.prepareStatement("Insert into customer values(?,?,?,?,?,?,?,?,?,?,?,?)");
			pr.setString(1, customer.getCustomer_Id());
			pr.setString(2,customer.getPassword());
			pr.setString(3,customer.getFirst_Name());
			pr.setString(4,customer.getLast_Name());
			pr.setInt(5,customer.getAge());
			pr.setString(6,customer.getGender());
			pr.setString(7,customer.getAddress());
			pr.setString(8,customer.getCity());
			pr.setString(9,customer.getState());
			pr.setLong(10,customer.getContact());
			pr.setLong(11,Long.parseLong(customer.getAccount_No()));
			pr.setString(12,customer.getEmail_Id());
			pr.executeUpdate();
			PreparedStatement pr1=con.prepareStatement("insert into account values(?,?,?,?)");
			pr1.setLong(1,Long.parseLong(customer.getAccount_No()));
			pr1.setString(2,customer.getAcc_type());
			pr1.setFloat(3,customer.getAmount());
			pr1.setString(4,customer.getCustomer_Id());
			pr1.executeUpdate();
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				pr.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return false;
	}

	public int update(Customer customer) {
		// TODO Auto-generated method stub
		int rows=0;
		try {
			pr=con.prepareStatement("Update customer set address=?,city=?,state=?,contact=?,email_id=? where customer_id=?");
			pr.setString(1, customer.getAddress());
			pr.setString(2, customer.getCity());
			pr.setString(3, customer.getState());
			pr.setLong(4, customer.getContact());
			pr.setString(5, customer.getEmail_Id());
			pr.setString(6, customer.getCustomer_Id());
			
			rows=pr.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				pr.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			MyDBConnection.closeConnection();
			
			
		}
		return rows;
	}

	public int passwordRequest(Customer customer) {
		// TODO Auto-generated method stub
		
		int rows=0;
		try {
			pr=con.prepareStatement("update customer set password=? where customer_id=?");
		    pr.setString(1, customer.getPassword());
            pr.setString(2,customer.getCustomer_Id());
            
            rows=pr.executeUpdate();
            
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				pr.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			MyDBConnection.closeConnection();
		}
		return rows;
	}

	public boolean forgetPassword(String customer_id) {
		// TODO Auto-generated method stub
		
		
		return false;
	}

	public void viewBalance() {
		// TODO Auto-generated method stub
		
	}

}

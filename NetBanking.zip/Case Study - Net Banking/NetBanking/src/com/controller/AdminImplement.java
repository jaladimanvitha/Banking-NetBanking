package com.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.connection.MyDBConnection;
import com.dao.AdminDao;
import com.model.Admin;

public class AdminImplement implements AdminDao{

	public int update(Admin admin) {
		// TODO Auto-generated method stub
		int rows=0;
		Connection con=null;
		PreparedStatement pr=null;
		try {
			con=MyDBConnection.getConnection();
			pr=con.prepareStatement("Update admin set address=?,city=?,state=?,contact=?,email_id=? where admin_id=?");
			pr.setString(1, admin.getAddress());
			pr.setString(2, admin.getCity());
			pr.setString(3, admin.getState());
			pr.setLong(4, admin.getContact());
			pr.setString(5, admin.getEmail_Id());
			pr.setString(6, admin.getAdmin_id());
			
			rows=pr.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				pr.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			MyDBConnection.closeConnection();
			
			
		}
		return rows;
	}

}

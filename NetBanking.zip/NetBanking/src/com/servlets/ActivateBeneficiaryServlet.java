package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.controller.BeneficiaryImplement;
import com.dao.BeneficiaryDao;
import com.model.Beneficiary;

/**
 * Servlet implementation class ActivateBeneficiaryServlet
 */
public class ActivateBeneficiaryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ActivateBeneficiaryServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		HttpSession session=request.getSession();
		//pw.print("1");
		//System.out.println("1");
		String acc_no=(String)session.getAttribute("acc_no");
		//pw.print(acc_no);
		Beneficiary b=new Beneficiary(acc_no,"Active");
		//pw.print("2");
		//System.out.println("2");
		BeneficiaryDao bd=new BeneficiaryImplement();
		//pw.print("3");
		//System.out.println("3");
		boolean cus=bd.activateDeactivateBeneficiary(b);
		//pw.print(cus);
		System.out.println(cus);
		if(cus==true){
			pw.println("<h3><i>Beneficiary is Activated</i></h3><br>");
			RequestDispatcher rd=request.getRequestDispatcher("Approval.jsp");
			rd.include(request, response);
		}
		
	}

}

package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.connection.MyDBConnection;
import com.controller.RequestApprovalImplement;
import com.dao.RequestApprovalDao;
import com.model.Account;
import com.model.DemandDraft;

/**
 * Servlet implementation class ApproveDDServlet
 */
public class ApproveDDServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ApproveDDServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		HttpSession session=request.getSession();
		String customer_id=(String)session.getAttribute("cid");
		System.out.println(customer_id);
		 float bal=0;
		 Connection con=null;
		 
		 try {
			 con=MyDBConnection.getConnection();
			PreparedStatement pr=con.prepareStatement("Select balance from account where customer_id=?");
			pr.setString(1, customer_id);
			
			ResultSet rs=pr.executeQuery();
			while(rs.next()) {
				bal=rs.getFloat(1);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 DemandDraft dd=new DemandDraft(customer_id,"Approved");
		 Account ac=new Account(customer_id,bal);
		 RequestApprovalDao ra=new RequestApprovalImplement();
		 boolean cus=ra.approveDemandDraft(dd, ac);
		 System.out.println(cus);
		 
		 if(cus==true) {
			 pw.println("<h3><i>Demand Draft request is Approved</i></h3><br>");
				RequestDispatcher rd=request.getRequestDispatcher("Approval.jsp");
				rd.include(request, response);
		 }

	}

}

package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.controller.AdminImplement;
import com.model.Admin;

/**
 * Servlet implementation class EditAdminServlet
 */
public class EditAdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditAdminServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
        PrintWriter pw = response.getWriter();
        HttpSession session = request.getSession();
        String admin_id = (String) session.getAttribute("a_id");
        String address = request.getParameter("address");
        String city = request.getParameter("city");
        String state = request.getParameter("state");
        Long contact = Long.parseLong(request.getParameter("Contact"));
        String email = request.getParameter("email");
        
        Admin a = new Admin();
        a.setAdmin_id(admin_id);
        a.setAddress(address);
        a.setCity(city);
        a.setState(state);
        a.setContact(contact);
        a.setEmail_Id(email);
     
     AdminImplement ad = new AdminImplement();
     int i = ad.update(a);
     if(i!=0)
     {
         
       session.setAttribute("address",address);
       session.setAttribute("city", city);
       session.setAttribute("state", state);
       session.setAttribute("contact", contact);
       session.setAttribute("email", email);
     
        pw.println("UPDATED SUCCESSFULLY");
        RequestDispatcher rd=request.getRequestDispatcher("Adminedit.html");
        rd.include(request, response);
     }
     else {
        pw.println("UPDATION FAILED");
        }
	}

}

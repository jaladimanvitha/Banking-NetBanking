package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.controller.PasswordImplement;
import com.model.ChangePassword;

/**
 * Servlet implementation class AdminChangePass
 */
public class AdminChangePass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminChangePass() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		HttpSession session=request.getSession();
		String old_pass=request.getParameter("old_pass");
		String new_pass=request.getParameter("new_pass");
		String con_pass=request.getParameter("re_pass");
		//Connection con=MyDBConnection.getConnection();
		String a_id=(String)session.getAttribute("a_id");
		String password=(String)session.getAttribute("a_pass");
		if(old_pass.equals(null)||old_pass==""||new_pass.equals(null)||new_pass==""||con_pass.equals(null)||con_pass==""){
			request.setAttribute("msg","All Fields are Mandatory");
	
			RequestDispatcher rd=request.getRequestDispatcher("AdminPass.jsp");
			rd.forward(request, response);
		}
		else if(!new_pass.equals(con_pass)){
			request.setAttribute("msg","New Password Do Not Match");
		
		
			RequestDispatcher rd=request.getRequestDispatcher("AdminPass.jsp");
			rd.forward(request, response);
		}
		else if(!password.equals(old_pass)){
			request.setAttribute("msg","Invalid Old Password");
		
			RequestDispatcher rd=request.getRequestDispatcher("AdminPass.jsp");
			rd.forward(request, response);
		}
		else{
			ChangePassword c=new ChangePassword(a_id,old_pass,new_pass,con_pass);
			PasswordImplement pi=new PasswordImplement();
			boolean cus=pi.changeAdminPassword(c);
			System.out.println(c);
			if(cus==true){
				pw.print("<b>Password Changed Sucessfully</b>");
				RequestDispatcher rd=request.getRequestDispatcher("AdminPassChange.html");
				rd.include(request, response);
			}
		}
	}

}

package com.servlets;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.connection.MyDBConnection;
public class ChequeRequestServlet1 extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		HttpSession session=request.getSession();
		String Account_no=request.getParameter("account_no");
		boolean st=false;
		Connection con=MyDBConnection.getConnection();
		try {
			PreparedStatement pr=con.prepareStatement("select * from  where Account_no=?");
			pr.setString(1, Account_no);
            ResultSet rs=pr.executeQuery();
		    	st=rs.next();
			if(st){
		    	session.setAttribute("acc_no",rs.getString(1));
			pw.print("<h1>Account number exists </h1>");
			}
			else {
		    	pw.print("<h1> Account no doesnt exist </h1>");
		    	RequestDispatcher rd=request.getRequestDispatcher("chequeRequest.html");

  			 }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	}
	

package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.controller.CustomerImplement;
import com.model.Customer;

/**
 * Servlet implementation class RegisterCustServlet
 */
public class RegisterCustServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterCustServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try{
	response.setContentType("text/html");
	PrintWriter pw=response.getWriter();
	String customer_id=request.getParameter("cust_id");
	String first_name=request.getParameter("f_name");
	String last_name=request.getParameter("l_name");
	int age=Integer.parseInt(request.getParameter("age"));	
	String gender=request.getParameter("gender");
	String address=request.getParameter("address");
	String city=request.getParameter("city");
	String state=request.getParameter("state");
	long contact=Long.parseLong(request.getParameter("Contact"));
	String account_no=request.getParameter("acc_no");
	String email_id=request.getParameter("email");
	String password=request.getParameter("pass");
	float amount=Long.parseLong(request.getParameter("amount"));
	String acc_type=request.getParameter("acc_type");
	 Customer cust=new Customer(customer_id,first_name,last_name,age,gender,address,city,state,contact,account_no,email_id,password,amount,acc_type);
	 CustomerImplement custI=new CustomerImplement();
	 boolean res=custI.register(cust);
	 if(res) {
		 pw.println("CUSTOMER ADDED SUCCESSFULLY..!!");
		 RequestDispatcher rd=request.getRequestDispatcher("AdminHome.jsp");
		 rd.include(request, response);
		 	 }
	 else{
		 pw.println("Sorry..You cannot be added");
	 }
		}
		catch( Exception e)
		{
			e.printStackTrace();
		}
	}

}

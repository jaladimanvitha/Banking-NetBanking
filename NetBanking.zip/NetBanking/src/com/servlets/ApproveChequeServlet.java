package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.controller.RequestApprovalImplement;

import com.model.ChequeBook;


/**
 * Servlet implementation class ApproveChequeServlet
 */
public class ApproveChequeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ApproveChequeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		HttpSession session=request.getSession();
		String customer_id=(String) session.getAttribute("cid");
		System.out.println(customer_id);
		ChequeBook cb=new ChequeBook(customer_id,"Approved");
		RequestApprovalImplement ra=new RequestApprovalImplement();
		boolean cus=ra.approveChequeBook(cb);
		System.out.println(cus);
		if(cus==true) {
			pw.println("<h3><i>Cheque Book request is Approved</i></h3><br>");
			RequestDispatcher rd=request.getRequestDispatcher("Approval.jsp");
			rd.include(request, response);
		}
		
	}

}

package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.connection.MyDBConnection;
import com.controller.RequestImplement;
import com.model.Account;
import com.model.DemandDraft;

/**
 * Servlet implementation class DDRequestServlet
 */
public class DDRequestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DDRequestServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html"); 
        PrintWriter pw = response.getWriter();
        
        long account_no=Long.parseLong(request.getParameter("acc_no"));
        String payee=request.getParameter("payee");
        float amount=Float.parseFloat(request.getParameter("amount"));
        HttpSession session = request.getSession();
        String customer_id= (String)session.getAttribute("cid");
        float bal=0;
          Connection con=null;
          PreparedStatement pr=null; 
          try {
                     con=MyDBConnection.getConnection();
               pr=con.prepareStatement("select balance from account where customer_id=? ");
               pr.setString(1,customer_id);
               ResultSet rs= pr.executeQuery();
               while(rs.next())
               {
                     bal = rs.getLong(1);
               }
               }catch (SQLException e1) {
                     
                     e1.printStackTrace();
               }
        Random rnd = new Random();
        long ddno = (long)1 + rnd.nextInt(999999);
        
        //long accno= (Long)hs.getAttribute("accno");
        //long cid= Long.parseLong(id);
        System.out.println(customer_id);
        String status="Requested";
        Date dateobj = new Date();
        java.sql.Date mySqlDate = new java.sql.Date(dateobj.getTime()); 
        DemandDraft dd=new DemandDraft(customer_id,account_no,ddno,payee,mySqlDate,amount,status);
        
        Account ac=new Account(customer_id,bal);
        System.out.println(ac.getCustomer_id());
        RequestImplement ri=new  RequestImplement();
          boolean cus=ri.requestdemanddraft(dd);
          System.out.println(cus);
          if(cus==true)
          {
                 pw.println("Request raised");
            RequestDispatcher rd = request.getRequestDispatcher("ddrequest.html");
                     rd.include(request, response);
          }
 }


}

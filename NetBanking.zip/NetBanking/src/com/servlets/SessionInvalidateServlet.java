package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class SessionInvalidateServlet
 */
public class SessionInvalidateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SessionInvalidateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession(false);
		if(session!=null)
		session.invalidate();
		PrintWriter pw=response.getWriter();
		pw.println("Logged Out Successfully");
		RequestDispatcher rd=request.getRequestDispatcher("Welcome2.html");
		rd.forward(request, response);
		
	}
//	  request.getRequestDispatcher("Welcome2.html").include(request, response);  
//      
//      HttpSession session = request.getSession(false);
//      if(session!=null)
//      session.invalidate(); 
//      PrintWriter pw=response.getWriter();
//    	pw.println("Logged Out Successfully");
//      
}  


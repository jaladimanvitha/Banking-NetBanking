package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.controller.BeneficiaryImplement;
import com.model.Beneficiary;

/**
 * Servlet implementation class AddBeneficiaryServlet
 */
public class AddBeneficiaryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddBeneficiaryServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
        PrintWriter pw = response.getWriter();
        HttpSession session = request.getSession();
        String account_no=request.getParameter("acc_no");
        String name=request.getParameter("name");
        long contact=Long.parseLong(request.getParameter("contact"));
        String email=request.getParameter("email");
        //Connection con=null;
        //con=MyDBConnection.getConnection();
        String id=(String)session.getAttribute("cid");
        String status="Inactive";
        Beneficiary b=new Beneficiary(id,account_no,name,contact,email,status);
        BeneficiaryImplement bi=new BeneficiaryImplement();
        boolean cus=bi.addBeneficiary(b);
        System.out.println(cus);
        if(cus==true){
        	pw.println("Beneficiary Added");
        	RequestDispatcher rd=request.getRequestDispatcher("CustHome.jsp");
        	rd.include(request, response);
        }
	}

}

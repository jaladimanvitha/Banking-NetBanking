package com.dao;

import java.sql.ResultSet;
import java.util.ArrayList;

import com.model.Transaction;

public interface TransactionDao {
        public ArrayList<ResultSet> viewAccountDetails(String customer_id);
        public boolean transferfund(Transaction transaction);
}

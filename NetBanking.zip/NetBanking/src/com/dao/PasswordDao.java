package com.dao;

import com.model.ChangePassword;

public interface PasswordDao {
     public boolean changeCustomerPassword(ChangePassword changePassword);
     public boolean changeAdminPassword(ChangePassword changePassword);
     public boolean changeACustomerPassword(String cust_id,String newpass);
}  

package com.dao;

import com.model.ChequeBook;
import com.model.DemandDraft;

public interface RequestDao {
       public boolean requestchequebook(ChequeBook chequebook);
       public boolean requestdemanddraft(DemandDraft demanddraft);
}

package com.dao;

import java.sql.ResultSet;

import com.model.Beneficiary;

public interface BeneficiaryDao {
	
	

	public ResultSet  viewBeneficiary(String cust_id);
	public boolean addBeneficiary(Beneficiary beneficiary);
	public boolean deleteBeneficiary(String accno);
	public boolean activateDeactivateBeneficiary(Beneficiary beneficiary);
}

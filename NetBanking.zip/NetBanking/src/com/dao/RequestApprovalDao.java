package com.dao;

import com.model.Account;
import com.model.ChequeBook;
import com.model.DemandDraft;

public interface RequestApprovalDao {
 public boolean approveChequeBook(ChequeBook chequeBook);
 public boolean approveDemandDraft(DemandDraft demanddraft,Account account);
 
}

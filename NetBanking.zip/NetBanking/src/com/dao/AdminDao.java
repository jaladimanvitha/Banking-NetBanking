package com.dao;

import com.model.Admin;

public interface AdminDao {
    public int update(Admin admin); 
}

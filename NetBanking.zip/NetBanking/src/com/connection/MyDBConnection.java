package com.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MyDBConnection{
	static Connection con=null;
	static Connection con1=null;
	
	public static Connection getConnection()
	{
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@172.16.153.233:1521:xe","user1","techm123");
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}
	public static void closeConection()
	{
		if(con!=null)
			try {
				con.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
	}
	public static Connection getConnection1()
	{
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con1=DriverManager.getConnection("jdbc:oracle:thin:@172.16.153.233:1521:xe","user1","techm123");
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con1;
	}
	public static void closeConection1()
	{
		if(con1!=null)
			try {
				con1.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
	}
}

package com.model;

public class ChequeBook {
	private String customer_Id;
	private String account_No;
	private long chk_Book_No;
	private String status;
	
	public ChequeBook() {
		super();
	}
	public ChequeBook(String customer_Id, String account_No, long chk_Book_No,
			String status) {
		super();
		this.customer_Id = customer_Id;
		this.account_No = account_No;
		this.chk_Book_No = chk_Book_No;
		this.status = status;
	}
	public ChequeBook(String customer_Id, String status) {
		super();
		this.customer_Id = customer_Id;
		this.status = status;
	}
	public String getCustomer_Id() {
		return customer_Id;
	}
	public void setCustomer_Id(String customer_Id) {
		this.customer_Id = customer_Id;
	}
	public String getAccount_No() {
		return account_No;
	}
	public void setAccount_No(String account_No) {
		this.account_No = account_No;
	}
	public long getChk_Book_No() {
		return chk_Book_No;
	}
	public void setChk_Book_No(long chk_Book_No) {
		this.chk_Book_No = chk_Book_No;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}

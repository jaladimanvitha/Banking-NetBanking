package com.model;

public class Customer {
	private String customer_Id;
	private String first_Name;
	private String last_Name;
	private int age;
	private String gender;
	private String address;
	private String city;
	private String state;
	private long contact;
	private String account_No;
	private String email_Id;
	private String password;
	private float amount;
	private String acc_type;
	public Customer() {
		super();
	}
	public Customer(String customer_Id, String first_Name, String last_Name,
			int age, String gender, String address, String city, String state,
			long contact, String account_No, String email_Id, String password,float amount,String acc_type) {
		super();
		this.customer_Id = customer_Id;
		this.first_Name = first_Name;
		this.last_Name = last_Name;
		this.age = age;
		this.gender = gender;
		this.address = address;
		this.city = city;
		this.state = state;
		this.contact = contact;
		this.account_No = account_No;
		this.email_Id = email_Id;
		this.password = password;
		this.amount = amount;
		this.acc_type = acc_type;
	}
	public String getCustomer_Id() {
		return customer_Id;
	}
	public void setCustomer_Id(String customer_Id) {
		this.customer_Id = customer_Id;
	}
	public String getFirst_Name() {
		return first_Name;
	}
	public void setFirst_Name(String first_Name) {
		this.first_Name = first_Name;
	}
	public String getLast_Name() {
		return last_Name;
	}
	public void setLast_Name(String last_Name) {
		this.last_Name = last_Name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public long getContact() {
		return contact;
	}
	public void setContact(long contact) {
		this.contact = contact;
	}
	public String getAccount_No() {
		return account_No;
	}
	public void setAccount_No(String account_No) {
		this.account_No = account_No;
	}
	public String getEmail_Id() {
		return email_Id;
	}
	public void setEmail_Id(String email_Id) {
		this.email_Id = email_Id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "Customer [customer_Id=" + customer_Id + ", first_Name="
				+ first_Name + ", last_Name=" + last_Name + ", age=" + age
				+ ", gender=" + gender + ", address=" + address + ", city="
				+ city + ", state=" + state + ", contact=" + contact
				+ ", account_No=" + account_No + ", email_Id=" + email_Id
				+ ", password=" + password + "]";
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public String getAcc_type() {
		return acc_type;
	}
	public void setAcc_type(String acc_type) {
		this.acc_type = acc_type;
	}

	
	}
	
	


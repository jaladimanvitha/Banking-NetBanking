package com.model;

import java.sql.Date;

public class DemandDraft {

	private String customer_Id;
	private long account_No;
	private long DD_No;
	private String payee;
	private Date date;
	private float amount;
	private String status;
	public DemandDraft() {
		super();
	}
	public DemandDraft(String customer_Id, long account_No, long dD_No,
			String payee, Date date, float amount, String status) {
		super();
		this.customer_Id = customer_Id;
		this.account_No = account_No;
		DD_No = dD_No;
		this.payee = payee;
		this.date = date;
		this.amount = amount;
		this.status = status;
	}
	public DemandDraft(String customer_Id, String status) {
		super();
		this.customer_Id = customer_Id;
		this.status = status;
	}
	public String getCustomer_Id() {
		return customer_Id;
	}
	public void setCustomer_Id(String customer_Id) {
		this.customer_Id = customer_Id;
	}
	public long getAccount_No() {
		return account_No;
	}
	public void setAccount_No(long account_No) {
		this.account_No = account_No;
	}
	public long getDD_No() {
		return DD_No;
	}
	public void setDD_No(long dD_No) {
		DD_No = dD_No;
	}
	public String getPayee() {
		return payee;
	}
	public void setPayee(String payee) {
		this.payee = payee;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	
}

package com.model;

import java.sql.Date;

public class Transaction {

	private String trans_Id;
	private String customer_Id;
	private long debit_AccNo;
	private long credit_AccNo;
	private Date trans_Date;
	private float amount;
	public Transaction() {
		super();
	}
	public Transaction(String trans_Id, String customer_Id, long debit_AccNo,
			long credit_AccNo, Date trans_Date, float amount) {
		super();
		this.trans_Id = trans_Id;
		this.customer_Id = customer_Id;
		this.debit_AccNo = debit_AccNo;
		this.credit_AccNo = credit_AccNo;
		this.trans_Date = trans_Date;
		this.amount = amount;
	}
	public String getTrans_Id() {
		return trans_Id;
	}
	public void setTrans_Id(String trans_Id) {
		this.trans_Id = trans_Id;
	}
	public String getCustomer_Id() {
		return customer_Id;
	}
	public void setCustomer_Id(String customer_Id) {
		this.customer_Id = customer_Id;
	}
	public long getDebit_AccNo() {
		return debit_AccNo;
	}
	public void setDebit_AccNo(long debit_AccNo) {
		this.debit_AccNo = debit_AccNo;
	}
	public long getCredit_AccNo() {
		return credit_AccNo;
	}
	public void setCredit_AccNo(long credit_AccNo) {
		this.credit_AccNo = credit_AccNo;
	}
	public Date getTrans_Date() {
		return trans_Date;
	}
	public void setTrans_Date(Date trans_Date) {
		this.trans_Date = trans_Date;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	
	
}

package com.model;

public class Reports {
	
	private Customer customer;
	private Beneficiary beneficiary;
	private ChequeBook chequeBook;
	private Account account;
	private Transaction transaction;
	
	public Reports() {
		super();
	}
	public Reports(Customer customer, Beneficiary beneficiary,
			ChequeBook chequeBook, Account account, Transaction transaction) {
		super();
		this.customer = customer;
		this.beneficiary = beneficiary;
		this.chequeBook = chequeBook;
		this.account = account;
		this.transaction = transaction;
		}
	
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Beneficiary getBeneficiary() {
		return beneficiary;
	}
	public void setBeneficiary(Beneficiary beneficiary) {
		this.beneficiary = beneficiary;
	}
	public ChequeBook getChequeBook() {
		return chequeBook;
	}
	public void setChequeBook(ChequeBook chequeBook) {
		this.chequeBook = chequeBook;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public Transaction getTransaction() {
		return transaction;
	}
	public void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}
	
	
}

package com.model;

public class Beneficiary {
	private String customer_Id;
	private String account_No;
	private String b_Name;
	private long mobile_No;
	private String email_Id;
	private String status;
	
	public Beneficiary() {
		super();
	}

	public Beneficiary(String customer_Id, String account_No, String b_Name,
			long mobile_No, String email_Id, String status) {
		super();
		this.customer_Id = customer_Id;
		this.account_No = account_No;
		this.b_Name = b_Name;
		this.mobile_No = mobile_No;
		this.email_Id = email_Id;
		this.status = status;
	}

	public Beneficiary(String account_No, String status) {
		super();
		this.account_No = account_No;
		this.status = status;
	}

	public String getCustomer_Id() {
		return customer_Id;
	}

	public void setCustomer_Id(String customer_Id) {
		this.customer_Id = customer_Id;
	}

	public String getAccount_No() {
		return account_No;
	}

	public void setAccount_No(String account_No) {
		this.account_No = account_No;
	}

	public String getB_Name() {
		return b_Name;
	}

	public void setB_Name(String b_Name) {
		this.b_Name = b_Name;
	}

	public long getMobile_No() {
		return mobile_No;
	}

	public void setMobile_No(long mobile_No) {
		this.mobile_No = mobile_No;
	}

	public String getEmail_Id() {
		return email_Id;
	}

	public void setEmail_Id(String email_Id) {
		this.email_Id = email_Id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	
}

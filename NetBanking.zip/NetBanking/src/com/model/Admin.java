package com.model;

public class Admin {
	private String admin_id;
	private String password;
	private String admin_name;
	private String branch;
	private String address;
	private String city;
	private String state;
	private long contact;
	private String email_Id;
	
	public Admin() {
		super();
	}
	
	
	public Admin(String admin_id, String password, String admin_name,
			String branch,String address,String city,String state,long contact,String email_Id) {
		super();
		this.admin_id = admin_id;
		this.password = password;
		this.admin_name = admin_name;
		this.branch = branch;
		this.address = address;
		this.city = city;
		this.state = state;
		this.contact = contact;
		this.email_Id = email_Id;
	}


	public String getAdmin_id() {
		return admin_id;
	}
	public void setAdmin_id(String admin_id) {
		this.admin_id = admin_id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAdmin_name() {
		return admin_name;
	}
	public void setAdmin_name(String admin_name) {
		this.admin_name = admin_name;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public long getContact() {
		return contact;
	}


	public void setContact(long contact) {
		this.contact = contact;
	}


	public String getEmail_Id() {
		return email_Id;
	}


	public void setEmail_Id(String email_Id) {
		this.email_Id = email_Id;
	}
	
	
}

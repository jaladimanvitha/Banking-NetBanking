package com.model;

public class ChangePassword {
	private String customer_Id;
	private String old_Pass;
	private String new_Pass;
	private String re_Pass;
	
	public ChangePassword() {
		super();
	}
	public ChangePassword(String customer_Id, String new_Pass) {
		super();
		this.customer_Id = customer_Id;
		this.new_Pass = new_Pass;
	}
	public ChangePassword(String customer_Id, String old_Pass, String new_Pass, String re_Pass) 
	{
		super();
		this.customer_Id = customer_Id;
		this.old_Pass = old_Pass;
		this.new_Pass = new_Pass;
		this.re_Pass = re_Pass;
	}
	public String getCustomer_Id() {
		return customer_Id;
	}
	public void setCustomer_Id(String customer_Id) {
		this.customer_Id = customer_Id;
	}
	public String getOld_Pass() {
		return old_Pass;
	}
	public void setOld_Pass(String old_Pass) {
		this.old_Pass = old_Pass;
	}
	public String getNew_Pass() {
		return new_Pass;
	}
	public void setNew_Pass(String new_Pass) {
		this.new_Pass = new_Pass;
	}
	public String getRe_Pass() {
		return re_Pass;
	}
	public void setRe_Pass(String re_Pass) {
		this.re_Pass = re_Pass;
	}
	
}

package com.model;

public class Account {
    private String customer_id;
    private String account_no;
    private String acc_type;
    private float balance;
    
	public Account() {
		super();
	}
	public Account(String customer_id, String account_no, String acc_type,
			float balance) {
		super();
		this.customer_id = customer_id;
		this.account_no = account_no;
		this.acc_type = acc_type;
		this.balance = balance;
	}
	
	
	public Account(String customer_id, float balance) {
		super();
		this.customer_id = customer_id;
		this.balance = balance;
	}
	public String getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}
	public String getAccount_no() {
		return account_no;
	}
	public void setAccount_no(String account_no) {
		this.account_no = account_no;
	}
	public String getAcc_type() {
		return acc_type;
	}
	public void setAcc_type(String acc_type) {
		this.acc_type = acc_type;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
    
}

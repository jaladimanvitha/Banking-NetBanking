package com.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.connection.MyDBConnection;
import com.dao.PasswordDao;
import com.model.ChangePassword;

public class PasswordImplement implements PasswordDao{

	public boolean changeCustomerPassword(ChangePassword changePassword) {
		// TODO Auto-generated method stub
		Connection con=null;
		
		try {
			con=MyDBConnection.getConnection();
			PreparedStatement pr=con.prepareStatement("update customer set password=? where customer_id=?");
			pr.setString(1,changePassword.getNew_Pass());
			pr.setString(2,changePassword.getCustomer_Id());
			int count=pr.executeUpdate();
			if(count>0){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return false;
	}

	public boolean changeAdminPassword(ChangePassword changePassword) {
		// TODO Auto-generated method stub
Connection con=null;
		
		try {
			con=MyDBConnection.getConnection();
			PreparedStatement pr=con.prepareStatement("update admin set password=? where admin_id=?");
			pr.setString(1,changePassword.getNew_Pass());
			pr.setString(2,changePassword.getCustomer_Id());
			int count=pr.executeUpdate();
			if(count>0){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}

	public boolean changeACustomerPassword(String cust_id, String newpass) {
		// TODO Auto-generated method stub
		Connection con=null;
		try {
			con=MyDBConnection.getConnection();
			PreparedStatement pr=con.prepareStatement("update customer set password=? where customer_id=?");
			pr.setString(1,newpass);
			pr.setString(2,cust_id);
			int count=pr.executeUpdate();
			if(count>0){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}

}

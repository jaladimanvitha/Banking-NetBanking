package com.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.connection.MyDBConnection;
import com.dao.RequestApprovalDao;
import com.model.Account;
import com.model.ChequeBook;
import com.model.DemandDraft;

public class RequestApprovalImplement implements RequestApprovalDao {

	public boolean approveChequeBook(ChequeBook chequeBook) {
		// TODO Auto-generated method stub
		Connection con=null;
		PreparedStatement pr=null;
		try {
			con=MyDBConnection.getConnection();
			 pr=con.prepareStatement("update chequebook set status=? where customer_id=?");
			pr.setString(1, chequeBook.getStatus());
			pr.setString(2, chequeBook.getCustomer_Id());
			
			int res=pr.executeUpdate();
			if(res>0) {
				return true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				pr.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}

	public boolean approveDemandDraft(DemandDraft demanddraft, Account account) {
		// TODO Auto-generated method stub
       Connection con=null;
       String type = null;
       PreparedStatement pr=null;
       PreparedStatement pr1=null;
       PreparedStatement pr2=null;
		try {
			con=MyDBConnection.getConnection();
			pr=con.prepareStatement("update demanddraft set status=? where customer_id=?");
			pr1=con.prepareStatement("update account set balance=? where customer_id=?");
			pr2=con.prepareStatement("Select account_type from account where customer_id=?");
			pr2.setString(1, demanddraft.getCustomer_Id());
			ResultSet rs=pr2.executeQuery();
			while(rs.next()){
				type=rs.getString(1);
			}
			pr.setString(1, demanddraft.getStatus());
			pr.setString(2, demanddraft.getCustomer_Id());
			if(type.equalsIgnoreCase("Savings")){
				int bal=(int)((int) demanddraft.getAmount()*3.5);
				pr1.setFloat(1,account.getBalance()-bal);
			}
			else{
				pr1.setFloat(1,account.getBalance());
			}
			pr1.setString(2,demanddraft.getCustomer_Id());
			int res1=pr.executeUpdate();
			int res2=pr1.executeUpdate();
			
			if(res1>0 && res2>0) {
				return true;
			}
				
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				pr2.close();
				pr1.close();
				pr.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return false;
	}

}

package com.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.connection.MyDBConnection;
import com.dao.BeneficiaryDao;
import com.model.Beneficiary;

public class BeneficiaryImplement implements BeneficiaryDao{

	public ResultSet viewBeneficiary(String cust_id) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean addBeneficiary(Beneficiary beneficiary) {
		// TODO Auto-generated method stub
		Connection con=null;
		
		try {
			con=MyDBConnection.getConnection();
			PreparedStatement pr=con.prepareStatement("insert into beneficiary values(?,?,?,?,?,?)");
			pr.setString(1,beneficiary.getAccount_No());
			pr.setString(2,beneficiary.getB_Name());
			pr.setLong(3,beneficiary.getMobile_No());
			pr.setString(4,beneficiary.getEmail_Id());
			pr.setString(5,"Inactive");
			pr.setString(6,beneficiary.getCustomer_Id());
			int res=pr.executeUpdate();
			PreparedStatement pr1=con.prepareStatement("insert into account values(?,?,?,?)");
			pr1.setLong(1, Long.parseLong(beneficiary.getAccount_No()));
			pr1.setString(2,"Salary");
			pr1.setFloat(3,1500);
			pr1.setString(4,beneficiary.getCustomer_Id());
			int res1=pr1.executeUpdate();
			if(res>0 && res1>0){
				return true;
			}
			con.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return false;
	}

	public boolean deleteBeneficiary(String accno) {
		// TODO Auto-generated method stub
        Connection con=null;
		
		try {
			con=MyDBConnection.getConnection();
			PreparedStatement pr=con.prepareStatement("delete from beneficiary where acc_no=?");
			pr.setString(1,accno);
			int res=pr.executeUpdate();
			if(res>0){
				return true;
			}
			con.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}

	public boolean activateDeactivateBeneficiary(Beneficiary beneficiary) {
		// TODO Auto-generated method stub
Connection con=null;
		
		try {
			con=MyDBConnection.getConnection();
			PreparedStatement pr=con.prepareStatement("update beneficiary set status=? where acc_no=?");
			System.out.println(beneficiary.getStatus());
			System.out.println(beneficiary.getAccount_No());
			pr.setString(1,beneficiary.getStatus());
			
			pr.setString(2,beneficiary.getAccount_No());
			int res=pr.executeUpdate();
			if(res>0){
				return true;
			}
			con.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}
      
}

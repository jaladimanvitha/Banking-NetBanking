package com.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;
import java.util.Random;

import com.connection.MyDBConnection;
import com.dao.RequestDao;
import com.model.ChequeBook;
import com.model.DemandDraft;

public class RequestImplement implements RequestDao {

	public boolean requestchequebook(ChequeBook chequebook) {
		// TODO Auto-generated method stub
		Connection con=null;
		PreparedStatement pr=null;
               
			try {
				con=MyDBConnection.getConnection();
	               long account_no=Long.parseLong(chequebook.getAccount_No());
	               String customer_id=chequebook.getCustomer_Id();
	               
				pr = con.prepareStatement("INSERT INTO chequebook VALUES(?,?,?,?)");
				pr.setLong(1, chequebook.getChk_Book_No());
	               pr.setLong(2, account_no);
	               pr.setString(3, chequebook.getStatus());
	               pr.setString(4,customer_id );
	               int res=pr.executeUpdate();
	               if(res>0){
	                     return true;
	               }
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				try {
					pr.close();
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
               
        
        

		return false;
	}

	public boolean requestdemanddraft(DemandDraft demanddraft) {
		// TODO Auto-generated method stub
		Connection con=null;
		PreparedStatement pr=null;
		try {
            con=MyDBConnection.getConnection();
            Random rnd = new Random();
            long dd_No = (long)1 + rnd.nextInt(999999);
            Date dateobj = new Date();
            java.sql.Date mySqlDate = new java.sql.Date(dateobj.getTime()); 
            long account_no=(demanddraft.getAccount_No());
            String customer_id=demanddraft.getCustomer_Id();
            pr=con.prepareStatement("INSERT INTO demanddraft VALUES(?,?,?,?,?,?,?)");
            pr.setLong(1, dd_No);
            pr.setLong(2, account_no);
            pr.setString(3, demanddraft.getPayee());
            pr.setDate(4, mySqlDate);
            pr.setFloat(5,demanddraft.getAmount());
            pr.setString(6, demanddraft.getStatus());
            pr.setString(7, customer_id);
            int res=pr.executeUpdate();
            if(res>0){
                  return true;
            }
     } catch (SQLException e) {
            e.printStackTrace();
     }finally{
            try {
            	pr.close();
                  con.close();
            } catch (SQLException e) {
                  e.printStackTrace();
            }
     }

		return false;
	}

}
